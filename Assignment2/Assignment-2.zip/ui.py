import model
import player
from os import system
from remove import Delete_Playlist, Delete_Song, Delete_Album, Delete_Artist, DeleteFrom_Playlist
from insertion import add_playlist, addto_playlist, add_song, add_album
from view_model import view_playlists, view_albums, view_artists, view_song, view_playlist, view_songs


while(True):
    system('cls')
    print("                     Welcome to Musicly")
    print("        1.PlayLists  2.Artists  3.Albums  4.Liberary")
    UserOption = input()
    if (UserOption == '1'):
        view_playlists()
        print('-----------')
        print("1.View Playlist")
        print("2.Add PlayList")
        print("3.Add songs to a Playlist")
        print("4.Delete PlayList")
        print("5.Back To Home")
        print("6.Exit")
        option = input()
        if (option == '1'):
            print("Enter Playlist name: ")
            name = input()
            order = input()
            view_playlist(name, order)
        if (option == '2'):
            print("Enter The Playlist's name: ")
            nam = input()
            print("Enter The Playlist's description: ")
            des = input()
            add_playlist(nam, des)
        if (option == '3'):
            print("Enter The Playlist's name: ")
            nam = input()
            print("How many songs do you want to add?")
            num = int(input())
            for i in range(num):
                print("Enter The song's name: ")
                snam = input()
                addto_playlist(nam, snam)
        if(option == '4'):
            print("Enter The Playlist's name: ")
            nam = input()
            Delete_Playlist(nam)
        if(option == '5'):
            continue
        if(option == '6'):
            break
    elif (UserOption == '2'):
        view_artists()
        print('-----------')
        print("1.Add Artist")
        print("2.Delete Artist")
        print("3.Back To Home")
        print("4.Exit")
        option = input()
        if (option == '1'):
            print("Enter The Artist's name: ")
            nam = input()
            #add_artist(nam)
        if (option == '2'):
            print("Enter The Artist's name: ")
            nam = input()
            Delete_Artist(nam)
        if(option == '3'):
            continue
        if(option == '4'):
            break
    elif (UserOption == '3'):
        view_albums()
        print('-----------')
        print("1.Add Album")
        print("2.Delete Album")
        print("3.Back To Home")
        print("4.Exit")
        option = input()
        if (option == '1'):
            print("Enter The Album's name: ")
            nam = input()
            # add_album(nam)
        if (option == '2'):
            print("Enter The Album's name: ")
            nam = input()
            Delete_Album(nam)
        if(option == '3'):
            continue
        if(option == '4'):
            break
    elif (UserOption == '4'):
        view_songs()
        print('-----------')
        print("1.Add song")
        print("2.Delete song")
        print("3.view song")
        print("4.Back To Home")
        print("5.Exit")
        option = input()
        if (option == '1'):
            print("Enter The song's link: ")
            path = input()
            # add_song(path)
        if (option == '2'):
            print("Enter The songs's name: ")
            nam = input()
            Delete_Song(nam)
        if(option == '3'):
            print("Enter The songs's name: ")
            nam = input()
            view_song(nam)
        if(option == '4'):
            continue
        if (option == '5'):
            break
